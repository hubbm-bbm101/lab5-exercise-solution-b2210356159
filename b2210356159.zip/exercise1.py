n = int(input("Enter the number:"))
sum_o = 0 
sum_e = 0
counter_even = 0

for i in range (1, n+1): # This loop controls for N input. Starting from 0 to N
    if(i%2):  # Even situations
        sum_o += i 
    else:   # Odd situations
        sum_e += i
        counter_even += 1

print("Sum of odd numbers: ", sum_o) #Sum of odd numbers printing
print("Average of even numbers: ", sum_e/counter_even) #Average of even numbers printing