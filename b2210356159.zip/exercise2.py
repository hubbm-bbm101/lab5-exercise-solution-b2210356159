mail_test = input("Enter your email : ") # We get the value as an input
if "@" in mail_test and "." in mail_test : # This loop controls containing @ and . characters
    print("your email is valid")
else:
    print("Your email is not valid. Try again")