import random
number = random.randint(0,100)
while True:
    guess = int(input("Guess please! :"))
    if(guess < number):
        print("Increase your number")
    elif(guess > number):
        print("Decrease your number")
    else:
        print("You guessed correctly!\n",number)
        break

